﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Automated_Parking_Lot_Management_System
{
    public partial class PrintTicket : Form
    {
        public PrintTicket()
        {
            InitializeComponent();
        }

        private void PrintTicket_Load(object sender, EventArgs e)
        {
            
        }
    }
}
