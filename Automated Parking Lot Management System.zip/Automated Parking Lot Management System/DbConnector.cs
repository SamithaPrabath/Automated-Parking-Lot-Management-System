﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Automated_Parking_Lot_Management_System
{
    internal class DbConnector
    {
        public string strCon = "Data Source=CHOK-PC;Initial Catalog=automated_parking_system_db;Integrated Security=True";
    }
}
