﻿namespace Automated_Parking_Lot_Management_System
{
    partial class Current_Status
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel31 = new System.Windows.Forms.Panel();
            this.slot18 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.panel27 = new System.Windows.Forms.Panel();
            this.slot5 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.panel26 = new System.Windows.Forms.Panel();
            this.slot17 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.panel23 = new System.Windows.Forms.Panel();
            this.slot13 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.panel21 = new System.Windows.Forms.Panel();
            this.slot9 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.slot4 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.slot16 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.slot12 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.slot8 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.slot3 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.slot15 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.slot11 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.slot7 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.slot2 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.slot14 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.slot10 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.slot6 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.slot1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel31.SuspendLayout();
            this.slot18.SuspendLayout();
            this.panel27.SuspendLayout();
            this.slot5.SuspendLayout();
            this.panel26.SuspendLayout();
            this.slot17.SuspendLayout();
            this.panel23.SuspendLayout();
            this.slot13.SuspendLayout();
            this.panel21.SuspendLayout();
            this.slot9.SuspendLayout();
            this.panel19.SuspendLayout();
            this.slot4.SuspendLayout();
            this.panel18.SuspendLayout();
            this.slot16.SuspendLayout();
            this.panel16.SuspendLayout();
            this.slot12.SuspendLayout();
            this.panel15.SuspendLayout();
            this.slot8.SuspendLayout();
            this.panel13.SuspendLayout();
            this.slot3.SuspendLayout();
            this.panel12.SuspendLayout();
            this.slot15.SuspendLayout();
            this.panel10.SuspendLayout();
            this.slot11.SuspendLayout();
            this.panel9.SuspendLayout();
            this.slot7.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.slot2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.slot14.SuspendLayout();
            this.panel4.SuspendLayout();
            this.slot10.SuspendLayout();
            this.panel3.SuspendLayout();
            this.slot6.SuspendLayout();
            this.slot1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(1435, 474);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(53, 29);
            this.label23.TabIndex = 30;
            this.label23.Text = "Full";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(1435, 371);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(85, 29);
            this.label22.TabIndex = 29;
            this.label22.Text = "Vacant";
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.Red;
            this.panel33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel33.Location = new System.Drawing.Point(1316, 463);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(104, 53);
            this.panel33.TabIndex = 25;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Location = new System.Drawing.Point(1316, 359);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(104, 53);
            this.panel32.TabIndex = 24;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.AutoSize = true;
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.tableLayoutPanel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 200F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 205F));
            this.tableLayoutPanel1.Controls.Add(this.panel31, 5, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel27, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel26, 5, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel23, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel21, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel19, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel18, 5, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel16, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel15, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel13, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel12, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel10, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel9, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.slot1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(53, 214);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1212, 506);
            this.tableLayoutPanel1.TabIndex = 28;
            // 
            // panel31
            // 
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.Controls.Add(this.slot18);
            this.panel31.Controls.Add(this.textBox18);
            this.panel31.Location = new System.Drawing.Point(1009, 408);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(195, 94);
            this.panel31.TabIndex = 41;
            // 
            // slot18
            // 
            this.slot18.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot18.Controls.Add(this.label21);
            this.slot18.Location = new System.Drawing.Point(-1, -1);
            this.slot18.Name = "slot18";
            this.slot18.Size = new System.Drawing.Size(200, 100);
            this.slot18.TabIndex = 2;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(3, 3);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(53, 38);
            this.label21.TabIndex = 22;
            this.label21.Text = "18";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox18.Location = new System.Drawing.Point(3, 3);
            this.textBox18.Multiline = true;
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(54, 55);
            this.textBox18.TabIndex = 0;
            this.textBox18.Text = "01";
            // 
            // panel27
            // 
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.slot5);
            this.panel27.Controls.Add(this.textBox17);
            this.panel27.Location = new System.Drawing.Point(4, 408);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(194, 94);
            this.panel27.TabIndex = 40;
            // 
            // slot5
            // 
            this.slot5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot5.Controls.Add(this.label8);
            this.slot5.Location = new System.Drawing.Point(-1, -1);
            this.slot5.Name = "slot5";
            this.slot5.Size = new System.Drawing.Size(200, 100);
            this.slot5.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 3);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 38);
            this.label8.TabIndex = 22;
            this.label8.Text = "05";
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox17.Location = new System.Drawing.Point(3, 3);
            this.textBox17.Multiline = true;
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(54, 55);
            this.textBox17.TabIndex = 0;
            this.textBox17.Text = "05";
            // 
            // panel26
            // 
            this.panel26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel26.Controls.Add(this.slot17);
            this.panel26.Controls.Add(this.textBox16);
            this.panel26.Location = new System.Drawing.Point(1009, 307);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(195, 94);
            this.panel26.TabIndex = 39;
            // 
            // slot17
            // 
            this.slot17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot17.Controls.Add(this.label20);
            this.slot17.Location = new System.Drawing.Point(-1, -1);
            this.slot17.Name = "slot17";
            this.slot17.Size = new System.Drawing.Size(200, 100);
            this.slot17.TabIndex = 2;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(3, 3);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(53, 38);
            this.label20.TabIndex = 22;
            this.label20.Text = "17";
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox16.Location = new System.Drawing.Point(3, 3);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(54, 55);
            this.textBox16.TabIndex = 0;
            this.textBox16.Text = "01";
            // 
            // panel23
            // 
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.slot13);
            this.panel23.Controls.Add(this.textBox15);
            this.panel23.Location = new System.Drawing.Point(607, 307);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(194, 94);
            this.panel23.TabIndex = 38;
            // 
            // slot13
            // 
            this.slot13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot13.Controls.Add(this.label16);
            this.slot13.Location = new System.Drawing.Point(-1, -1);
            this.slot13.Name = "slot13";
            this.slot13.Size = new System.Drawing.Size(200, 100);
            this.slot13.TabIndex = 2;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 3);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(53, 38);
            this.label16.TabIndex = 22;
            this.label16.Text = "13";
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox15.Location = new System.Drawing.Point(3, 3);
            this.textBox15.Multiline = true;
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(54, 55);
            this.textBox15.TabIndex = 0;
            this.textBox15.Text = "13";
            // 
            // panel21
            // 
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.slot9);
            this.panel21.Controls.Add(this.textBox14);
            this.panel21.Location = new System.Drawing.Point(406, 307);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(194, 94);
            this.panel21.TabIndex = 37;
            // 
            // slot9
            // 
            this.slot9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot9.Controls.Add(this.label12);
            this.slot9.Location = new System.Drawing.Point(-1, -1);
            this.slot9.Name = "slot9";
            this.slot9.Size = new System.Drawing.Size(200, 100);
            this.slot9.TabIndex = 2;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(53, 38);
            this.label12.TabIndex = 22;
            this.label12.Text = "09";
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(3, 3);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(54, 55);
            this.textBox14.TabIndex = 0;
            this.textBox14.Text = "09";
            // 
            // panel19
            // 
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.slot4);
            this.panel19.Controls.Add(this.textBox13);
            this.panel19.Location = new System.Drawing.Point(4, 307);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(194, 94);
            this.panel19.TabIndex = 36;
            // 
            // slot4
            // 
            this.slot4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot4.Controls.Add(this.label7);
            this.slot4.Location = new System.Drawing.Point(-1, -1);
            this.slot4.Name = "slot4";
            this.slot4.Size = new System.Drawing.Size(200, 100);
            this.slot4.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 38);
            this.label7.TabIndex = 22;
            this.label7.Text = "04";
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(3, 3);
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(54, 55);
            this.textBox13.TabIndex = 0;
            this.textBox13.Text = "04";
            // 
            // panel18
            // 
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.slot16);
            this.panel18.Controls.Add(this.textBox12);
            this.panel18.Location = new System.Drawing.Point(1009, 206);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(195, 94);
            this.panel18.TabIndex = 35;
            // 
            // slot16
            // 
            this.slot16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot16.Controls.Add(this.label19);
            this.slot16.Location = new System.Drawing.Point(-1, -1);
            this.slot16.Name = "slot16";
            this.slot16.Size = new System.Drawing.Size(200, 100);
            this.slot16.TabIndex = 2;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(3, 3);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(53, 38);
            this.label19.TabIndex = 22;
            this.label19.Text = "16";
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox12.Location = new System.Drawing.Point(3, 3);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(54, 55);
            this.textBox12.TabIndex = 0;
            this.textBox12.Text = "01";
            // 
            // panel16
            // 
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.slot12);
            this.panel16.Controls.Add(this.textBox11);
            this.panel16.Location = new System.Drawing.Point(607, 206);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(194, 94);
            this.panel16.TabIndex = 34;
            // 
            // slot12
            // 
            this.slot12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot12.Controls.Add(this.label15);
            this.slot12.Location = new System.Drawing.Point(-1, -1);
            this.slot12.Name = "slot12";
            this.slot12.Size = new System.Drawing.Size(200, 100);
            this.slot12.TabIndex = 2;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(3, 3);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 38);
            this.label15.TabIndex = 22;
            this.label15.Text = "12";
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox11.Location = new System.Drawing.Point(3, 3);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(54, 55);
            this.textBox11.TabIndex = 0;
            this.textBox11.Text = "12";
            // 
            // panel15
            // 
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.slot8);
            this.panel15.Controls.Add(this.textBox10);
            this.panel15.Location = new System.Drawing.Point(406, 206);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(194, 94);
            this.panel15.TabIndex = 33;
            // 
            // slot8
            // 
            this.slot8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot8.Controls.Add(this.label11);
            this.slot8.Location = new System.Drawing.Point(-1, -1);
            this.slot8.Name = "slot8";
            this.slot8.Size = new System.Drawing.Size(200, 100);
            this.slot8.TabIndex = 2;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(53, 38);
            this.label11.TabIndex = 22;
            this.label11.Text = "08";
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox10.Location = new System.Drawing.Point(3, 3);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(54, 55);
            this.textBox10.TabIndex = 0;
            this.textBox10.Text = "08";
            // 
            // panel13
            // 
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.slot3);
            this.panel13.Controls.Add(this.textBox9);
            this.panel13.Location = new System.Drawing.Point(4, 206);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(194, 94);
            this.panel13.TabIndex = 32;
            // 
            // slot3
            // 
            this.slot3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot3.Controls.Add(this.label6);
            this.slot3.Location = new System.Drawing.Point(-1, -1);
            this.slot3.Name = "slot3";
            this.slot3.Size = new System.Drawing.Size(200, 100);
            this.slot3.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(53, 38);
            this.label6.TabIndex = 22;
            this.label6.Text = "03";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox9.Location = new System.Drawing.Point(3, 3);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(54, 55);
            this.textBox9.TabIndex = 0;
            this.textBox9.Text = "03";
            // 
            // panel12
            // 
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.slot15);
            this.panel12.Controls.Add(this.textBox8);
            this.panel12.Location = new System.Drawing.Point(1009, 105);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(195, 94);
            this.panel12.TabIndex = 31;
            // 
            // slot15
            // 
            this.slot15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot15.Controls.Add(this.label18);
            this.slot15.Location = new System.Drawing.Point(-1, -1);
            this.slot15.Name = "slot15";
            this.slot15.Size = new System.Drawing.Size(200, 100);
            this.slot15.TabIndex = 2;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(3, 3);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 38);
            this.label18.TabIndex = 22;
            this.label18.Text = "15";
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox8.Location = new System.Drawing.Point(3, 3);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(54, 55);
            this.textBox8.TabIndex = 0;
            this.textBox8.Text = "15";
            // 
            // panel10
            // 
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.slot11);
            this.panel10.Controls.Add(this.textBox7);
            this.panel10.Location = new System.Drawing.Point(607, 105);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(194, 94);
            this.panel10.TabIndex = 30;
            // 
            // slot11
            // 
            this.slot11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot11.Controls.Add(this.label14);
            this.slot11.Location = new System.Drawing.Point(-1, -1);
            this.slot11.Name = "slot11";
            this.slot11.Size = new System.Drawing.Size(200, 100);
            this.slot11.TabIndex = 2;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(3, 3);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(53, 38);
            this.label14.TabIndex = 22;
            this.label14.Text = "11";
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox7.Location = new System.Drawing.Point(3, 3);
            this.textBox7.Multiline = true;
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(54, 55);
            this.textBox7.TabIndex = 0;
            this.textBox7.Text = "11";
            // 
            // panel9
            // 
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.slot7);
            this.panel9.Controls.Add(this.textBox6);
            this.panel9.Location = new System.Drawing.Point(406, 105);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(194, 94);
            this.panel9.TabIndex = 29;
            // 
            // slot7
            // 
            this.slot7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot7.Controls.Add(this.label10);
            this.slot7.Location = new System.Drawing.Point(-1, -1);
            this.slot7.Name = "slot7";
            this.slot7.Size = new System.Drawing.Size(200, 100);
            this.slot7.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 3);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(53, 38);
            this.label10.TabIndex = 22;
            this.label10.Text = "07";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(3, 3);
            this.textBox6.Multiline = true;
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(54, 55);
            this.textBox6.TabIndex = 0;
            this.textBox6.Text = "07";
            // 
            // panel7
            // 
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.textBox5);
            this.panel7.Location = new System.Drawing.Point(4, 105);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(194, 94);
            this.panel7.TabIndex = 28;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.slot2);
            this.panel8.Controls.Add(this.label3);
            this.panel8.Location = new System.Drawing.Point(-1, -1);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(200, 100);
            this.panel8.TabIndex = 2;
            // 
            // slot2
            // 
            this.slot2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot2.Controls.Add(this.label5);
            this.slot2.Location = new System.Drawing.Point(-1, -1);
            this.slot2.Name = "slot2";
            this.slot2.Size = new System.Drawing.Size(200, 100);
            this.slot2.TabIndex = 23;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 38);
            this.label5.TabIndex = 22;
            this.label5.Text = "02";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(53, 38);
            this.label3.TabIndex = 22;
            this.label3.Text = "01";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(3, 3);
            this.textBox5.Multiline = true;
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(54, 55);
            this.textBox5.TabIndex = 0;
            this.textBox5.Text = "02";
            // 
            // panel6
            // 
            this.panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel6.Controls.Add(this.slot14);
            this.panel6.Controls.Add(this.textBox4);
            this.panel6.Location = new System.Drawing.Point(1009, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(195, 94);
            this.panel6.TabIndex = 27;
            // 
            // slot14
            // 
            this.slot14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot14.Controls.Add(this.label17);
            this.slot14.Location = new System.Drawing.Point(-1, -1);
            this.slot14.Name = "slot14";
            this.slot14.Size = new System.Drawing.Size(200, 100);
            this.slot14.TabIndex = 2;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(3, 3);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 38);
            this.label17.TabIndex = 22;
            this.label17.Text = "14";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(3, 3);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(54, 55);
            this.textBox4.TabIndex = 0;
            this.textBox4.Text = "14";
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.slot10);
            this.panel4.Controls.Add(this.textBox3);
            this.panel4.Location = new System.Drawing.Point(607, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(194, 94);
            this.panel4.TabIndex = 26;
            // 
            // slot10
            // 
            this.slot10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot10.Controls.Add(this.label13);
            this.slot10.Location = new System.Drawing.Point(-1, -1);
            this.slot10.Name = "slot10";
            this.slot10.Size = new System.Drawing.Size(200, 100);
            this.slot10.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(3, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(53, 38);
            this.label13.TabIndex = 22;
            this.label13.Text = "10";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(3, 3);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(54, 55);
            this.textBox3.TabIndex = 0;
            this.textBox3.Text = "10";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.slot6);
            this.panel3.Controls.Add(this.textBox2);
            this.panel3.Location = new System.Drawing.Point(406, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(194, 94);
            this.panel3.TabIndex = 25;
            // 
            // slot6
            // 
            this.slot6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot6.Controls.Add(this.label9);
            this.slot6.Location = new System.Drawing.Point(-1, -1);
            this.slot6.Name = "slot6";
            this.slot6.Size = new System.Drawing.Size(200, 100);
            this.slot6.TabIndex = 2;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 38);
            this.label9.TabIndex = 22;
            this.label9.Text = "06";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(3, 3);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(54, 55);
            this.textBox2.TabIndex = 0;
            this.textBox2.Text = "06";
            // 
            // slot1
            // 
            this.slot1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.slot1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.slot1.Controls.Add(this.label4);
            this.slot1.Location = new System.Drawing.Point(4, 4);
            this.slot1.Name = "slot1";
            this.slot1.Size = new System.Drawing.Size(194, 94);
            this.slot1.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 38);
            this.label4.TabIndex = 22;
            this.label4.Text = "01";
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Purple;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(-4, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1767, 43);
            this.label2.TabIndex = 27;
            this.label2.Text = "Current Status";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1757, 83);
            this.label1.TabIndex = 26;
            this.label1.Text = "AUTOMATED PARKING SLOT MANAGEMENT SYSTEM";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.UseMnemonic = false;
            this.label1.UseWaitCursor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Image = global::Automated_Parking_Lot_Management_System.Properties.Resources.refresh;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.Location = new System.Drawing.Point(53, 129);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(163, 68);
            this.button1.TabIndex = 31;
            this.button1.Text = "Refresh";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Current_Status
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1756, 896);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.panel33);
            this.Controls.Add(this.panel32);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Current_Status";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Current_Status";
            this.Load += new System.EventHandler(this.Current_Status_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.slot18.ResumeLayout(false);
            this.slot18.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.slot5.ResumeLayout(false);
            this.slot5.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.slot17.ResumeLayout(false);
            this.slot17.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.slot13.ResumeLayout(false);
            this.slot13.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.slot9.ResumeLayout(false);
            this.slot9.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.slot4.ResumeLayout(false);
            this.slot4.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.slot16.ResumeLayout(false);
            this.slot16.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.slot12.ResumeLayout(false);
            this.slot12.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.slot8.ResumeLayout(false);
            this.slot8.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.slot3.ResumeLayout(false);
            this.slot3.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.slot15.ResumeLayout(false);
            this.slot15.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.slot11.ResumeLayout(false);
            this.slot11.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.slot7.ResumeLayout(false);
            this.slot7.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.slot2.ResumeLayout(false);
            this.slot2.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.slot14.ResumeLayout(false);
            this.slot14.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.slot10.ResumeLayout(false);
            this.slot10.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.slot6.ResumeLayout(false);
            this.slot6.PerformLayout();
            this.slot1.ResumeLayout(false);
            this.slot1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel slot18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel slot5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel slot17;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel slot13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel slot9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel slot4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel slot16;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel slot12;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel slot8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel slot3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel slot15;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel slot11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel slot7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel slot2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel slot14;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel slot10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel slot6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel slot1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}